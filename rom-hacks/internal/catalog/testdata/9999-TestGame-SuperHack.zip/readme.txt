Use with:

(No Intro)
File:               Test Game (USA).sfc
Size (Bytes):       32768
CRC32:              FF7CE628
MD5:                869DB35CF996B64E1A1515A33254EB2A
